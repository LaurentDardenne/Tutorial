using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultiKey
{
 // Origine :
 // http://www.e-naxos.com/Blog/post/2008/09/30/Utiliser-des-cles-composees-dans-lesdictionnaires.aspx
 // Auteur : Olivier Dahan aka Merlin
  
    class Program
    {
        static void Main(string[] args)
        {
            // Test of IEquatable in ComposedKey
            var k1 = new ComposedKey("Olivier", 589);
            var k2 = new ComposedKey("Bill", 9744);
            var k3 = new ComposedKey("Olivier", 589);

            Console.WriteLine("{0} =? {1} : {2}",k1,k2,(k1==k2));
            Console.WriteLine("{0} =? {1} : {2}",k1,k3,(k1==k3));
            Console.WriteLine("{0} =? {1} : {2}",k2,k1,(k2==k1));
            Console.WriteLine("{0} =? {1} : {2}",k2,k2,(k2==k2));
            Console.WriteLine("{0} =? {1} : {2}",k2,k3,(k2==k3));
            
            // Build a dictionnary using the composed key
            var dict = new Dictionary<ComposedKey, string>()
                           {
                               {new ComposedKey("Olivier",145), "resource A"},
                               {new ComposedKey("Yoda", 854), "resource B"},
                               {new ComposedKey("Valérie", 9845), "resource C"},
                               {new ComposedKey("Obiwan", 326), "resource D"},
                           };

            // Find associated resources by key

            var fk1 = new ComposedKey("Yoda", 854);
            var s = dict.ContainsKey(fk1) ? dict[fk1] : "No Resource Found";
            // must return 'resource B'
            Console.WriteLine("Key '{0}' is associated with resource '{1}'",fk1,s);

            var fk2 = new ComposedKey("Yoda", 999);
            var s2 = dict.ContainsKey(fk2) ? dict[fk2] : "No Resource Found";
            // must return 'No Resource Found'
            Console.WriteLine("Key '{0}' is associated with resource '{1}'", fk2, s2);



            Console.ReadLine();

        }

        public class ComposedKey : IEquatable<ComposedKey>
        {
            private string name;
            public string Name
            {
                get { return name; }
                set { name = value; }
            }

            private int passKey;
            public int PassKey
            {
                get { return passKey; }
                set { passKey = value; }
            }

            public ComposedKey(string name, int passKey)
            {
                this.name = name;
                this.passKey = passKey;
            }

            public override string ToString()
            {
                return name + " " + passKey;
            }

            public bool Equals(ComposedKey obj)
            {
                if (ReferenceEquals(null, obj)) return false;
                if (ReferenceEquals(this, obj)) return true;
                return Equals(obj.name, name) && obj.passKey == passKey;
            }

            public override bool Equals(object obj)
            {
                if (ReferenceEquals(null, obj)) return false;
                if (ReferenceEquals(this, obj)) return true;
                if (obj.GetType() != typeof (ComposedKey)) return false;
                return Equals((ComposedKey) obj);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    return ((name != null ? name.GetHashCode() : 0)*397) ^ passKey;
                }
            }

            public static bool operator ==(ComposedKey left, ComposedKey right)
            {
                return Equals(left, right);
            }

            public static bool operator !=(ComposedKey left, ComposedKey right)
            {
                return !Equals(left, right);
            }
        }
    }
}
