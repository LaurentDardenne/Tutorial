using System;
using System.Text;
using System.IO;
using System.Collections;
using log4net.Util;
using log4net.ObjectRenderer;
using System.Management.Automation;

namespace PSLog4NET
{
    public class PSObjectRenderer : PSObject,IObjectRenderer
    {
        #region IObjectRenderer Membres

        public void RenderObject(log4net.ObjectRenderer.RendererMap rendererMap, object obj, System.IO.TextWriter writer)
        {
		    if (rendererMap == null)
			{
				throw new ArgumentNullException("rendererMap");
			}

			if (obj == null)
			{
				writer.Write(SystemInfo.NullText);
				return;
			}
            PSObjectRenderer Instance = obj as PSObjectRenderer;
            if (Instance != null)
             //On laisse le scripteur red�clarer la m�thode ToString via add-member
            { writer.Write("{0}", Instance.ToString()); }
            else
            { writer.Write(SystemInfo.NullText); }
        }
        #endregion 
    }
    
    public class ObjectRenderer : IObjectRenderer
    {
        #region IObjectRenderer Membres

        public void RenderObject(log4net.ObjectRenderer.RendererMap rendererMap, object obj, System.IO.TextWriter writer)
        {
            if (rendererMap == null)
            {
                throw new ArgumentNullException("rendererMap");
            }

            if (obj == null)
            {
                writer.Write(SystemInfo.NullText);
                return;
            }
            ObjectRenderer Instance = obj as ObjectRenderer;
            if (Instance != null)
            //On laisse le scripteur red�clarer la m�thode ToString via add-member
            { writer.Write("*{0}*", Instance.ToString()); }
            else
            { writer.Write(SystemInfo.NullText); }
        }
        #endregion
    }
}
