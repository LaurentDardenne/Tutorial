# PackageDebugTools.ps1
#
# Contient une suite de fonctions li�es au debug/trace

function Get-CallStack{
#Auteur Bruce Payette
 #Erreur : Get-Variable : The scope number '5' exceeds the number of active scopes
trap { continue }
0..100 | foreach {
                 $var = Get-Variable -scope $_ myinvocation
                  #le dernier �l�ment du tableau est vide
                 $var.Value.PositionMessage -replace "`n"
                 }
}

function ParseStack([string[]] $Stack)
{  #On analyse des cha�nes du type: At line:48 char:7+ level1 <<<<
   #Tableau de cha�nes provenant d'un appel � Get-CallStack
   #Ex:     
   #     Write-Debug "Pile d'appel : $(ParseStack $(Get-CallStack))"
   
  $Result=new-object System.Text.StringBuilder
  #le premier �l�ment du tableau contient l'appel � Get-CallStack
  
   #Parcours inverse
  for($i=$Stack.Count-1; $i -ge 1;$i--)
  {   
     if ($Stack[$i] -match "^(.*)\+(.*) <<<<")
      {  #Ajoute un s�parateur sauf pour le premier
        if ($i -ne $Stack.Count-2) 
         {[void]$Result.Append(":")} 
        [void]$Result.Append($Matches[2].Trim()) 
      }
  }
 $Result.ToString();
}

function Write-Properties ($From, $PropertyName ="*", [Switch] $Pipeline, [Switch] $Debug)
{ #Affiche le contenu de toutes les propri�t�s d'un objet
  #
  # $From         : l'objet � interroger, 
  # $PropertyName : le nom de la propri�t�, ce nom peut contenir des jokers,
  # $Pipeline     : indique si le r�sultat est �mis dans le pipeline
  # $Debug        : indique si le r�sultat est envoy� vers le debugger 
  #
  #Exemples :
  # $a=dir
  # Write-Properties $a[-1] 
  # Write-Properties $a[-1] -Pipeline |%{Write-host $_ -fore DarkGreen}
  # Res=Write-Properties $a[-1] -Debug -Pipeline 
  
  foreach ($p in Get-Member -In $From -MemberType *Property -Name $propertyName|Sort name)
   {  
      $Result ="$($P.Name) : $($From.$($P.Name))"
      
      if ( $Pipeline.IsPresent)  {$result}
      else  {Write-Host $Result}
      if ( $Debug.IsPresent)  
       {
          #CommandLineParameters en PS v2 seulement
         $Source=$MyInvocation.CommandLineParameters."From".ToString()
         [int] $level=1
         [string] $category="WP-$Source"
          #Inop�rant si aucun d�bugger n'est actif
         [System.Diagnostics.Debugger]::Log($level, $category, $Result)
       }
  }     
}
