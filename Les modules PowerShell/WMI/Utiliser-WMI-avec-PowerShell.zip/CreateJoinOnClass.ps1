$o=([wmiclass]"\\.\root\TestVues:JoinedPartitionDisk")
$o.psbase.qualifiers
$o.psbase.Properties
