using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TestWMIEvent
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnStopProcess_Click(object sender, EventArgs e)
        {

        }

        private void btnStartProcess_Click(object sender, EventArgs e)
        {

        }

        private void btnStopAllWatching_Click(object sender, EventArgs e)
        {

        }

        private void btnRunProcess_Click(object sender, EventArgs e)
        {

        }

        private void btnCreateNewFile_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {

        }

        private void btnUnknownEvent_Click(object sender, EventArgs e)
        {

        }
    }
}