Function Fonction2-4
{  
 Process{ 
    Write-Host "Process Fonction2-4" -f Cyan
    Write-host "`tDonn�es dans la fonction2-4 : $_" -F Cyan
    $_
 }
}
