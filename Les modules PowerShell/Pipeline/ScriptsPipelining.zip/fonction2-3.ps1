Function Fonction2-3
{  
 End{ 
    Write-Host "End Fonction2-3" -f Cyan
    Write-host "`tDonn�es dans la fonction2-3 : $input" -F Cyan
    $input.Reset()
    $input
 }
}
