Function Fonction2-1
{  
    Write-host "`tDonn�es dans la fonction2-1 : $input" -F Yellow
    $input
}
