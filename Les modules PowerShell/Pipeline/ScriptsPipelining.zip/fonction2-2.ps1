Function Fonction2-2
{  
    Write-host "`tDonn�es dans la fonction2-2 : $input" -F Yellow
    $input.Reset()
    $input
}
