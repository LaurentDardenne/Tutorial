﻿ #Exécute une tâche donnée ( et ses dépendances) déclarée dans un fichier  
Invoke-psake .\Script10.ps1 Init