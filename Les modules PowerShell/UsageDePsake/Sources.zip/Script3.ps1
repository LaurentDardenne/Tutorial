﻿#Déclare une tâche nommée 'Default', déclenche une exception car default ne peut pas être associé à une action
Task default {Write-Host "Exécute du code"}