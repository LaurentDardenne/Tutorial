﻿Task Init {
   Write-Host "Tâche Init: dépendance imbriquée. On initialise la construction."
}
