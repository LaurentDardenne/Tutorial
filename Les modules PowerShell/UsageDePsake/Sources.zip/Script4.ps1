﻿#Déclare une tâche nommée 'Default', déclenche une exception la construction d'appel est erronée
Task default UneAutreTache
Task UneAutreTache {Write-Host "UneAutreTache : exécute du code"}