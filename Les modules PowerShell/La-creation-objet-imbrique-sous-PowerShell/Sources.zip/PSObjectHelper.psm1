﻿#PSObjectHelper

#Import-LocalizedData -BindingVariable PSObjectHelperMsgs -Filename PsObjectHelperLocalizedData.psd1 -EA Stop
          
Function New-TypedVariable{
 # $Value peut être encapsulé dans un PSObject  avant l'appel :
 # New-TypedVariable Informations (new-object PSObject($Value))
  param(
     [Parameter(Position=1, Mandatory=$true)]
     [ValidateNotNullOrEmpty()]
    [String] $VariableName,
     [Parameter(Position=2, Mandatory=$true)]
     [AllowNull()]     
    $Value,     
    [switch] $ReadOnly
  )
  
  function private:New-VariableInLocalScope {
       #On crée une variable dans une nouvelle portée
       #évitant ainsi d'écraser un des paramètres de la fonction New-TypedVariable
       # portant le même nom que $VariableName.
       #Le nom de la variable devient le nom du membre. 
      New-Variable $VariableName -value $Value
      gv $VariableName                        
  }

  $Variable=private:New-VariableInLocalScope
  if ($ReadOnly) 
   {$Variable.Options="ReadOnly"}
    #On renvoi l'objet variable, celle-ci servira à créer le membre via 
    #le constructeur de la classe PSVariableProperty
  $Variable
}#New-TypedVariable

Function New-PSVariableProperty{
#Crée un membre de type PSVariableProperty (affiché comme un NoteProperty).    
  param(
     [Parameter(Position=1, Mandatory=$true)]
     [ValidateNotNullOrEmpty()]
    [String] $MemberName,
     [Parameter(Position=2, Mandatory=$true)]
     [AllowNull()]
    $Value,  
    [switch] $ReadOnly
  )
  New-Object System.Management.Automation.PSVariableProperty( (New-TypedVariable $MemberName $Value -ReadOnly:$ReadOnly) )        
} #New-PSVariableProperty

Function New-ArrayReadOnly {
 param([ref]$Tableau)
   #La méthode AsReadOnly retourne un wrapper en lecture seule pour le tableau spécifié.
   #On recherche les informations de la méthode publique spécifiée.  
  [System.Reflection.MethodInfo] $Methode = [System.Array].GetMethod("AsReadOnly")
  
   #Crée une méthode générique
   #On précise le même type que celui déclaré pour la variable $Tableau
  $MethodeGenerique = $Methode.MakeGenericMethod($Tableau.Value.GetType().GetElementType())
  
   #Appel la méthode générique créée qui renvoi 
   #une collection en lecture seule, par exemple :
   # [System.Collections.ObjectModel.ReadOnlyCollection``1[System.String]]
  $TableauRO=$MethodeGenerique.Invoke($null,@(,$Tableau.Value.Clone()))
  ,$TableauRO
} #New-ArrayReadOnly

function Get-VariableType {
#If a PSVariable is $null, it is impossible to get his type.  PS v1,v2,v3
#One must read the _convertTypes member of ArgumentTypeConverterAttribute class.
#http://poshcode.com/998
    param([string]$Name)
    Write-Debug ("Call : {0}" -F $MyInvocation.InvocationName) 
    get-variable $name | select -expand attributes | ? {
        $_.gettype().name -eq "ArgumentTypeConverterAttribute" } | % {
        $_.gettype().invokemember("_convertTypes", "NonPublic,Instance,GetField", $null, $_, @())
    }
   Write-Debug ("End : {0}" -F $MyInvocation.InvocationName)
}

function Get-Interface {
#http://www.nivot.org/post/2009/03/28/PowerShell20CTP3ModulesInPracticeClosures

#.Synopsis
#   Allows PowerShell to call specific interface implementations on any .NET object. 
#.Description
#   Allows PowerShell to call specific interface implementations on any .NET object. 
#
#   As of v2.0, PowerShell cannot cast .NET instances to a particular interface. This makes it
#   impossible (shy of reflection) to call methods on explicitly implemented interfaces.   
#.Parameter Object
#   An instance of a .NET class from which you want to get a reference to a particular interface it defines.
#.Parameter InterfaceType
#   An interface type, e.g. [idisposable], implemented by the target object.
#.Example
#   // a class with explicitly implemented interface   
#   public class MyObj : IDisposable {
#      void IDisposable.Dispose()
#   }
#   
#   ps> $o = new-object MyObj
#   ps> $i = get-interface $o ([idisposable])
#   ps> $i.Dispose()      
#.ReturnValue
#   A PSCustomObject with ScriptMethods and ScriptProperties representing methods and properties on the target interface.
#.Notes
# AUTHOR:    Oisin Grehan http://www.nivot.org/
# LASTEDIT:  2009-03-28 18:37:23
# REVISION:  0.2

    [CmdletBinding()]
    param(
        [ValidateNotNull()]
        $Object,
        
        [ValidateScript( { $_.IsInterface } )]
        [type]$InterfaceType
    )

    $script:t  = $Object.GetType()
    
    try {
        
        $script:m  = $t.GetInterfaceMap($InterfaceType)

    } catch [argumentexception] {
        
        throw "Interface $($InterfaceType.Name) not found on ${t}!"
    }

    $script:im = $m.InterfaceMethods
    $script:tm = $m.TargetMethods
    
    # TODO: use param blocks in functions instead of $args
    #       so method signatures are visible via get-member
    
    $body = {
         param($o, $i) 
         
         $script:t  = $o.GetType()
         $script:m  = $t.GetInterfaceMap($i)
         $script:im = $m.InterfaceMethods
         $script:tm = $m.TargetMethods
                  
         for ($ix = 0; $ix -lt $im.Count; $ix++) {
            
            $mb = $im[$ix]

            # for the function body, we close over $ix to capture the index
            # so even on the next iteration of this loop, the $ix value will
            # be frozen within the function's scriptblock body
            set-item -path function:script:$($mb.Name) -value {

                # call corresponding target method
                $tm[$ix].Invoke($o, $args)

            }.GetNewClosure() -verbose -force

            if (!$mb.IsSpecialName) {
                # only export the function if it is not a getter or setter.
                Export-ModuleMember $mb.Name -verbose
            }
         }
    }

    write-verbose $body.tostring()    
    
    # create dynamic module
    $module = new-module -ScriptBlock $body -Args $Object, $InterfaceType -Verbose
    
    # generate method proxies - all exported members become scriptmethods
    # however, we are careful not to export getters and setters.
    $custom = $module.AsCustomObject()
    
    # add property proxies - need to use scriptproperties here.
    # modules cannot expose true properties, only variables and 
    # we cannot intercept variables get/set.
    
    $InterfaceType.GetProperties() | % {

        $propName = $_.Name
        $getter   = $null
        $setter   = $null
       
        if ($_.CanRead) {
            
            # where is the getter methodinfo on the interface map?
            $ix = [array]::indexof($im, $_.GetGetMethod())
            
            # bind the getter scriptblock to our module's scope
            # and generate script to call target method
            #
            # NOTE: we cannot use a closure here because sessionstate
            #       is rebound to the module's, and $ix would be lost
            $getter = $module.NewBoundScriptBlock(
                [scriptblock]::create("`$tm[{0}].Invoke(`$o, @())" -f $ix))
        }
        
        if ($_.CanWrite) {
            
            # where is the setter methodinfo on the interface map?
            $ix = [array]::indexof($im, $_.GetSetMethod())
            
            # bind the setter scriptblock to our module's scope
            # and generate script to call target method
            #
            # NOTE: we cannot use a closure here because sessionstate
            #       is rebound to the module's, and $ix would be lost
            $setter = $module.NewBoundScriptBlock(
                [scriptblock]::create(
                    "param(`$value); `$tm[{0}].Invoke(`$o, `$value)" -f $ix))
        }
        
        # add our property to the pscustomobject
        $prop = new-object management.automation.psscriptproperty $propName, $getter, $setter
        $custom.psobject.properties.add($prop)
    }
    
    # insert the interface name at the head of the typename chain (for get-member info)
    $custom.psobject.TypeNames.Insert(0, $InterfaceType.FullName)
    
    # dump our pscustomobject to pipeline
    $custom
} #et-Interface

function Protect-Variable {
#http://poshcode.org/2991
  param(
  [Parameter(Mandatory=$true,Position=0)][String]$Name, 
  [Int]$Scope = 1,
  [Parameter(ParameterSetName="ValidateScriptBlock")][ScriptBlock]$ScriptBlock,
  [Parameter(ParameterSetName="ValidateCount")][Int]$MinCount,
  [Parameter(ParameterSetName="ValidateCount")][Int]$MaxCount,
  [Parameter(ParameterSetName="ValidateLength")][Int]$MinLength,
  [Parameter(ParameterSetName="ValidateLength")][Int]$MaxLength,
  [Parameter(ParameterSetName="ValidatePattern")][Regex]$Pattern,
  [Parameter(ParameterSetName="ValidateRange")][Int]$MinValue,
  [Parameter(ParameterSetName="ValidateRange")][Int]$MaxValue,
  [Parameter(ParameterSetName="ValidateSet")][String[]]$Set,
  [Parameter(ParameterSetName="ValidateNotNull")][Switch]$NotNull,
  [Parameter(ParameterSetName="ValidateNotNullOrEmpty")][Switch]$NotEmpty
  )
   $Variable = Get-Variable $Name -Scope $Scope
   
   if($ScriptBlock) {
      $Attribute = new-object System.Management.Automation.ValidateScriptAttribute $ScriptBlock
      $Variable.Attributes.Add($Attribute)
   }
   if($MinCount -or $MaxCount) {
      if(!$MinCount) { $MinCount = [Int]::MinValue }
      if(!$MaxCount) { $MaxCount = [Int]::MaxValue }
      $Attribute = new-object System.Management.Automation.ValidateCountAttribute $MinCount, $MaxCount
      $Variable.Attributes.Add($Attribute)
   }
   if($MinLength -or $MaxLength) {
      $Attribute = new-object System.Management.Automation.ValidateLengthAttribute $MinLength, $MaxLength
      $Variable.Attributes.Add($Attribute)
   }
   if($Pattern) {
      $Attribute = new-object System.Management.Automation.ValidatePatternAttribute $Pattern
      $Variable.Attributes.Add($Attribute)
   }
   if($MinValue -or $MaxValue) {
      $Attribute = new-object System.Management.Automation.ValidateRangeAttribute $MinValue, $MaxValue
      $Variable.Attributes.Add($Attribute)
   }
   if($Set) {
      $Attribute = new-object System.Management.Automation.ValidateSetAttribute $Set
      $Variable.Attributes.Add($Attribute)
   }
   if($NotNull) {
      $Attribute = new-object System.Management.Automation.ValidateNotNullAttribute
      $Variable.Attributes.Add($Attribute)
   }
   if($NotEmpty) {
      $Attribute = new-object System.Management.Automation.ValidateNotNullOrEmptyAttribute
      $Variable.Attributes.Add($Attribute)
   }
} #Protect-Variable

Function New-PSCustomObjectFunction {
    #crée une fonction génèrant un objet personnalisé simple
    #tous ses paramètres sont obligatoires et ne sont pas typé
    #
    # Par défaut génère du code sans la signature du mot clé Function
    # Le paramètre -FILE génére du code avec la signature du mot clé Function 
    # Le paramètre -AsPSVariableProperty génére un objet dont 
    #  les propriétés sont basées sur la classe PSVariableProperty. Requière le module PSObjectHelper   
    
#L'appel suivant : 
# 
# $Name="ParsingDirective"
# New-PSCustomObjectFunction $Name 'Name','Line' | Set-Item Function:"New-$Name" -Force
#  
# 
# génére le code suivant: 
# 
# param(
#          [Parameter(Mandatory=$True,position=0)]
#         $Name,
#          [Parameter(Mandatory=$True,position=1)]
#         $Line
# )
#   
#   #Les paramétres liés définissent aussi les propriétés de l'objet
#  $O=New-Object PSObject -Property $PSBoundParameters
#  $O.PsObject.TypeNames.Insert(0,"ParsingDirective")
#  $O|Add-Member ScriptMethod ToString {'{0}:{1}' -F $this.Name,$this.Line} -Force -Passthru
#  
# 
# Celui-ci peut être directement utilisé lors de la création d'une fonction à l'aide du provider :
#  
# $Name="ParsingDirective"
# New-PSCustomObjectFunction $Name 'Name','Line' | Set-Item Function:"New-$Name" -Force
# $o=New-ParsingDirective 'Debug' '10'
# $o
# $o.psobject.TypeNames
#  
# 
# On peut vouloir créer une fonction avec la déclaration complète : 
# 
# $Code=New-PSCustomObjectFunction 'ParsingDirective' 'Name','Line' -File
# $Code|
#  Set-Content C:\Temp\New-ParsingDirective.ps1
# Type C:\Temp\New-ParsingDirective.ps1
#  
# 
# Une possible simplification de la saisie : 
# 
# Function ql {$args}
# New-PSCustomObjectFunction 'Test' (ql  QL avec une fonction comportant de nombreux paramètres facilite la saisie) -File
#      
     
  param(
       [Parameter(Mandatory=$true,position=0)]
       [ValidateNotNullOrEmpty()]
      $Noun,
       [Parameter(Mandatory=$true,position=1)]
       [ValidateNotNullOrEmpty()]
      [String[]]$Parameters,
      [switch] $File,
      [switch] $AsPSVariableProperty
  )

$Borne=$Parameters.count-1
$code=@"
$(if ($File) {"Function New-$Noun{"})
param(
    $(For ($I=0;$I -le $Borne;$I++)
      { $Name=$Parameters[$I]
        @"
`t [Parameter(Mandatory=`$True,position=$I)]
`t`$${Name}$(if ($I -Ne $borne) {",`r`n"})
"@
      } 
     )     
)
  #Les paramétres liés définissent aussi les propriétés de l'objet
 $( if ($AsPSVariableProperty) 
    {
@'  
  $O=New-Object PSObject
  $PSBoundParameters.GetEnumerator()|
   Foreach {
     $O.PSObject.Properties.Add( (New-PSVariableProperty $_.Key $_.Value -ReadOnly) ) 
   }
'@
   }
   else
  { '$O=New-Object PSObject -Property $PSBoundParameters' }
  ) 
 
 `$O.PsObject.TypeNames.Insert(0,"$Noun")
 `$O

$(if ($File) {"}# New-$Noun"})
"@
$Code
}#New-PSCustomObjectFunction
 
function New-MatchesObject{
 #A partir d'une chaîne de caractères,
 #construit un objet personnalisé à l'aide d'une regex
 #utilisant des captures nommées.
 
  #Exemple :
  #   #hashtable de paramètrages
  # $MyObject=@{
  #   #hashtable de création d'objets
  #  SMB=@{ 
  #      #Ces entrées portent les mêmes noms 
  #      #que les paramètres de la fonction New-MatchesObject. 
  #      #Ce qui autorise le splatting
  #      
  #      #Hashtable de création d'un objet
  #      #Exemple : analyse d'attribut AD extensionAttributeN 
  #     Res_CN=@{
  #        #Nom du type affiché par Get-member ou $Variable.PsObject.TypeNames
  #      TypeName='MY.SMB.Res_CN'
  #       #Expression régulière contenant des captures nommées
  #       #celles-ci seront utilisées pour construire des propriètés d'objets PS personnalisés 
  #      Regex='^extensionAttribute(?<Type>1)#CN=(?<CN>.*?),'
  #       #On supprime dans la variable automatique $Matches les clés indiquées
  #      Keys=0,1
  #     }
  #     
  #     Res_DN=@{
  #       TypeName='MY.SMB.Res_DN'
  #       Regex='^extensionAttribute(?<Type>1)#(?<DistinguishedName>.*$)'
  #       Keys=0,1
  #     }
  #  };
  #  #Others=@{...} 
  # }#$MyObject
  # 
  # $S="extensionAttribute1#CN=MyCN,..."
  # 
  #  #Le splatting ne fonctionne avec @Myobject.SMB.Res_CN 
  # $Parameters=$Myobject.SMB.Res_CN
  # $o=New-MatchesObject $S @Parameters
  # $o|gm
  # $O
  # 
  # $S2="extensionAttribute1#MyDN"
  # $Parameters=$Myobject.SMB.Res_DN
  # $o2=New-MatchesObject $S2 @Parameters
  # $o2|gm
  # $O2
 
 param (
       #Objet sur lequel on exécute la regex
      [Parameter(Mandatory=$true,position=0)]
      [ValidateNotNullOrEmpty()]
     $InputObject, 
     
       #Nom du type de l'objet PS
      [Parameter(Mandatory=$true,position=1)]
      [ValidateNotNullOrEmpty()]
    [String] $TypeName,
      
       #Expression régulière appliquée sur le paramètre InputObject
      [Parameter(Mandatory=$true,position=2)]
      [ValidateNotNullOrEmpty()]
    [String] $Regex,
      
       #En cas de succès de la regex,
       #on supprime les noms de clé indiquées dans la hashtable $Matches
      [Parameter(Mandatory=$false,position=3)]
      [ValidateNotNullOrEmpty()]
       #la clé 0 contient l'intégralité de ligne analysée
    [Object[]] $Keys=0
 )
 Write-debug "New-MatchesObject"
 if ($InputObject -match $Regex)
 {
   $Keys|
    Foreach {
      Write-Debug "Remove key = $_"
      $matches.Remove($_)
    }
   Write-debug "Construction d'un objet de type : $($TypeName)"
   $Object=New-Object PSCustomObject -Property $Matches
   $Object.PsObject.TypeNames.Insert(0,$TypeName)
   Write-Output $Object
  } 
}#New-MatchesObject