#
# Windows PowerShell in Action
#
# Chapter 7 Parameterized Hello World examples
#
# This script takes a name as a single parameter
# defaulted to "world".
#

param($name="world")
"Hello $name!"

