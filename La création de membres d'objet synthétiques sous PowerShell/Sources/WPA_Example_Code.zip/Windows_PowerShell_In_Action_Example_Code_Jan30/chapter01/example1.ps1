#
# Windows PowerShell in Action
#
# Chapter 1 Example 1
#
# This is the basic "Hello world!" script
#

"Hello world!"
