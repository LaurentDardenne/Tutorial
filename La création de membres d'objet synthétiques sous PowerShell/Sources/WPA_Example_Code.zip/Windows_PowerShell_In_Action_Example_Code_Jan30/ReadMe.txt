Hello and welcome to the "Windows PowerShell in Action" source code examples.

This code is taken from the examples provided in the book "Windows PowerShell
in Action" from Manning Publications. The samples are broken down by book chapter.
Note that not all chapters have corresponding code. In those cases, the examples
in the book are simple, interactive examples and weren't worth extracting. Also, in
some cases the samples have been slightly altered from what's in the book to make them
a little easier to run standalone. And finally, there are a couple of additional
examples showing WinForm programming in PowerShell that have been included in the
"chapter11" directory.

Feel free to use this code for whatever purpose you see fit, as long as you don't claim
to own or have written it.

Thanks.
Bruce Payette
Author: Windows PowerShell in Action
Windows PowerShell Technical Lead,
Microsoft Corporation
January 2007