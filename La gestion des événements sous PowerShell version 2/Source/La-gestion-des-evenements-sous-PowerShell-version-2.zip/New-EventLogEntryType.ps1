function New-EventLogEntryType([string]$EventLogName="Windows PowerShell")
{ #cr�e un �v�nement de test dans l'eventlog $EventLogName
 $Event=new-object System.Diagnostics.EventLog($EventLogName)
 $Event.Source="TestEventing"
 $Event.WriteEntry("Test �v�nement",[System.Diagnostics.EventLogEntryType]::Information)
}
