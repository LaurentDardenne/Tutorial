#D�clenchement d'un event d'un objet au sein d'un scriptblock d'un event d'une Winform cr��e dans une session PowerShell.  
#La Winform est active, le process Notepad est actif
#On ferme Notepad dans la fonction OnClick_btnAddData
#Le traitement de l'event Exited bloque le traitement de l'�v�nement OnClick_btnAddData de la Winform tant que le
# code de l'event Exited n'est pas termin�. Ensuite le traitement de l'�v�nement OnClick_btnAddData reprend. 
#
#Le m�canisme de gestion de la file d'attente de PowerShell ne g�re pas la boucle de message de la Winform. 
. ".\TestFrmRunSpace2.ps1"
Unregister-Event *
Remove-Job *
$lstBxInformations.Items.clear()
$btnAddData.Enabled=$true

$Process=Microsoft.PowerShell.Management\start-process Notepad.exe �pass -WindowStyle Minimized 
$null=Register-ObjectEvent $Process Exited -SourceIdentifier monEvent �Action {
 Write-Warning "begin Event"
 1..100|% {$lstBxInformations.Items.AddRange("Dans event Exited $_");sleep -m 200} #;$Form1.Refresh()}
 Write-Warning "End Event" 
 
}

$Form1.ShowDialog()
 # L'insertion des donn�es dans la listbox se fait correctement 
 # soit par l'un soit par l'autre des deux traitements d'�v�nements (PS et Winform), mais les deux 
 # ne s'ex�cutent pas en parall�le (thread bloquant).
$lstBxInformations.items

