#D�claration et gestion d'un event d'un objet 
#La Winform est active, le process Notepad est actif
#On ferme Notepad � l'ext�rieur de la session PowerShell 
#Tant que la fen�tre Windows est active l'event 'Exited' est en attente de d�clenchement
# jusqu'a ce que du code PowerShell soit d�clench� via un event de la Winform, par exemple par le bouton "Fermer".
#une fois celui-ci d�clench�, la Winform reste fig�e qq instants. 
#
#La boucle de message de la Winform ne traite donc pas la file d'attente de PowerShell.

. ".\TestFrmRunSpace1.ps1"
Unregister-Event *
Remove-Job *
$lstBxInformations.Items.clear()

$Process=Microsoft.PowerShell.Management\start-process Notepad.exe �pass -WindowStyle Minimized 
$null=Register-ObjectEvent $Process Exited -SourceIdentifier monEvent �Action {
 sleep -m 200
 Write-Warning "begin Event"
 $Fichiers=Dir c:\windows -rec|%{$_.Fullname}
 Write-Warning "Add lstbx in Event"
 $lstBxInformations.Items.AddRange($Fichiers)
 Write-Warning "End Event" 
 
}

$Form1.ShowDialog()
 #on supprime le process avant d'ex�cuter la fen�tre
 #La gestion PS de l'event r�ussi � s'�x�cuter avant la boucle de message de la Winform,
 # celle-ci reste fig�e qq instants pendant le traitement de l'event Exited 
#Get-Process Notepad|Stop-Process;$Form1.ShowDialog()
