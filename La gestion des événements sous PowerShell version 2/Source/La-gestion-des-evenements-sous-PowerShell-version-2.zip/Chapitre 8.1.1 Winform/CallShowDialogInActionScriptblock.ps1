# Copier le contenu de ce script dans la console, probl�me de port�e.

#Affiche une fen�tre dans un scriptblock d'un �v�nement PowerShell.  
#La console est inaccessible tant que la form est active.
#C'est le comportement normal, car la m�thode ShowDialog() est bloquante.

$Error.clear() 
. ".\TestFrmRunSpace2.ps1"
Unregister-Event *
Remove-Job *
$lstBxInformations.Items.clear()

$null=Register-EngineEvent "RunWin" �Action {
 Write-Warning "Run Winform"
 $btnAddData.Enabled=$true
 $global:Form1.ShowDialog()
 Write-Warning "Winform closed"
}

$null=new-event RunWin
Write-Warning "Suite dans la console"
 #Les erreurs d�clench�es par le traitement de la winform ne sont plus affich�s � l'�cran
$error
 #l'erreur suivant est ici d� � un bug de ps v2
 #��}�� de fermeture manquante dans le bloc d'instruction.

