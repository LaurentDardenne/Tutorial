$timer  = New-Object Timers.Timer
$timer.Interval = 10
$Count=0
$JobTimer=Register-ObjectEvent -inputObject $timer -eventName Elapsed -sourceIdentifier Timer.Random -Action {
  $Global:Count++
  Write-Host "Count=$Count"
}


$null=Register-ObjectEvent $JobTimer StateChanged -SourceIdentifier "StateChanged" -Action { 
  if ($EventArgs.JobStateInfo.ToString() -eq 'Stopped')
    {Write-host "Status : $State" -fore green}
}

 #l'abonnement StateChanged est arr�t� AVANT l'abonnement Timer.Random
 #Pas de gestion du status du job  
$timer.Enabled = $true;sleep -m 50; Unregister-Event * -verbose

 #l'abonnement StateChanged est arr�t� APRES l'abonnement Timer.Random
 #Gestion du status du job
#$timer.Enabled = $true;sleep 1; Unregister-Event Timer.Random -verbose; Unregister-Event "StateChanged" -verbose