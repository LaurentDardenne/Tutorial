#Les �v�nements en attente sont trait�s avant de supprimer l'abonnement
$timer  = New-Object Timers.Timer
 #10 sinon aucun event n'est trait�
$timer.Interval = 10
$Count=0
$JobTimer=Register-ObjectEvent -inputObject $timer -eventName Elapsed -sourceIdentifier Timer.Random -Action {
  $Global:Count++
  Write-Host "Count=$Count"
  $Count;
   #laisse du temps au timer de se d�clencher
  sleep -m 20}

$timer.Enabled = $true
&{
   #laisse du temps au gestionnaire de se d�clencher  
  sleep -m 50
   #on affiche le nombre d'�l�ments que contient le pipeline avant l'arr�t de l'abonnement 
  Write-host "Reste-t-il des donn�es ? $($JobTimer.HasMoreData). `$count=$Count. Stop ->$(get-date -format 'hh:mm:ss'). Events trait�s $((Receive-job $JobTimer -keep).count)" -fore green
   #Annule l'abonnement, traite les �v�n�ment restant avant de rendre la main
  Unregister-Event * -verbose
  Write-host "Reste-t-il des donn�es ? $($JobTimer.HasMoreData). `$count=$Count $(get-date -format 'hh:mm:ss') " -fore green
}

 #on r�cup�re du pipeline du job le m�me nombre d'�l�ment que $count
Write-host "Fin count =$count`tEvents trait�s $((Receive-job $JobTimer -keep).count)"  -fore green
