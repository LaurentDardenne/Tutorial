# Copier le contenu de ce script dans la console, probl�me de port�e.

#Affiche une fen�tre dans un scriptblock d'un �v�nement PowerShell.  
#La console est inaccessible tant que la form est active.
#C'est le comportement normal, car la m�thode ShowDialog() est bloquante.
#
#Tant que la Winform est active, et bien que l'on d�clenche un second �venement PowerShell en son sein, 
#le second �v�n�ment reste en attente. Celui-ci sera trait� d�s que le traitement du premier �v�nement 
# se terminera (en fermant la fen�tre).

$Error.clear()
. ".\TestFrmRunSpace2.ps1"
Unregister-Event *
Remove-Job *
$lstBxInformations.Items.clear()
$btnAddData.Enabled=$true
$Process=Microsoft.PowerShell.Management\start-process Notepad.exe �pass -WindowStyle Minimized 
$null=Register-ObjectEvent $Process Exited -SourceIdentifier monEvent �Action {
 Write-Warning "begin Event"
 1..100|% {$lstBxInformations.Items.AddRange("Dans event Exited $_");sleep -m 50} #;$Form1.Refresh()}
 Write-Warning "End Event" 
 
}

$null=Register-EngineEvent "RunWin" �Action {
 Write-Warning "Run Winform"
 $Form1.ShowDialog()
 Write-Warning "Winform closed"
}

$null=new-event RunWin
Write-Warning "Suite dans la console"
 #Les erreurs d�clench�es par le traitement de la winform ne sont plus affich�s � l'�cran
$error
#l'erreur suivant est ici d� � un bug de ps v2
 #��}�� de fermeture manquante dans le bloc d'instruction.


