################################################################################ 
#
#  Nom     : TestFrmRunSpace1.ps1
#  Version : 0.2
#  Auteur  :
#  Date    : le 02/06/2010
@"
Historique :
(Soit substitution CVS)
$Log$
(soit substitution SVN)
$LastChangedDate$
$Rev$
"@>$Null 
#
################################################################################

# Chargement des assemblies externes
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][Reflection.Assembly]::LoadWithPartialName("System.Drawing")

$btnClose = new-object System.Windows.Forms.Button
$lstBxInformations = new-object System.Windows.Forms.ListBox
$lblListe = new-object System.Windows.Forms.Label
$txtBxInformations = new-object System.Windows.Forms.TextBox
$btnAddData = new-object System.Windows.Forms.Button
$ckBxAllListe = new-object System.Windows.Forms.CheckBox
#
# btnClose
#
$btnClose.Location = new-object System.Drawing.Point(205, 231)
$btnClose.Name = "btnClose"
$btnClose.Size = new-object System.Drawing.Size(75, 23)
$btnClose.TabIndex = 0
$btnClose.Text = "Fermer"
$btnClose.UseVisualStyleBackColor = $true
function OnClick_btnClose{
	$Form1.Close()
}

$btnClose.Add_Click( { OnClick_btnClose } )
#
# lstBxInformations
#
$lstBxInformations.FormattingEnabled = $true
$lstBxInformations.Location = new-object System.Drawing.Point(15, 25)
$lstBxInformations.Name = "lstBxInformations"
$lstBxInformations.Size = new-object System.Drawing.Size(259, 69)
$lstBxInformations.TabIndex = 1
#
# lblListe
#
$lblListe.AutoSize = $true
$lblListe.Location = new-object System.Drawing.Point(12, 9)
$lblListe.Name = "lblListe"
$lblListe.Size = new-object System.Drawing.Size(177, 13)
$lblListe.TabIndex = 2
$lblListe.Text = "Donn�es provenant d'un runspace :"
#
# txtBxInformations
#
$txtBxInformations.Location = new-object System.Drawing.Point(15, 125)
$txtBxInformations.Multiline = $true
$txtBxInformations.Name = "txtBxInformations"
$txtBxInformations.ScrollBars =[System.Windows.Forms.ScrollBars]::Both
$txtBxInformations.Size = new-object System.Drawing.Size(259, 90)
$txtBxInformations.TabIndex = 3
#
# btnAddData
#
$btnAddData.Location = new-object System.Drawing.Point(15, 230)
$btnAddData.Name = "btnAddData"
$btnAddData.Size = new-object System.Drawing.Size(112, 23)
$btnAddData.TabIndex = 4
$btnAddData.Text = "D�clenche l'event"
$btnAddData.UseVisualStyleBackColor = $true
$btnAddData.Enabled=$true
function OnClick_btnAddData{
  Get-Process Notepad|Stop-Process 
  1..100|% { $lstBxInformations.Items.Add("Dans OnClickBouton $_")}
 $btnAddData.Enabled=$false
}

$btnAddData.Add_Click( { OnClick_btnAddData } )
#
# ckBxAllListe
#
$ckBxAllListe.AutoSize = $true
$ckBxAllListe.Location = new-object System.Drawing.Point(15, 100)
$ckBxAllListe.Name = "ckBxAllListe"
$ckBxAllListe.Size = new-object System.Drawing.Size(110, 17)
$ckBxAllListe.TabIndex = 5
$ckBxAllListe.Text = "Peuple les 2 listes"
$ckBxAllListe.UseVisualStyleBackColor = $true
function OnCheckedChanged_ckBxAllListe{
	[void][System.Windows.Forms.MessageBox]::Show("L'�v�nement ckBxAllListe.Add_CheckedChanged n'est pas impl�ment�.")
}

$ckBxAllListe.Add_CheckedChanged( { OnCheckedChanged_ckBxAllListe } )
#
$Form1 = new-object System.Windows.Forms.form
#
$Form1.ClientSize = new-object System.Drawing.Size(292, 266)
$Form1.Controls.Add($ckBxAllListe)
$Form1.Controls.Add($btnAddData)
$Form1.Controls.Add($txtBxInformations)
$Form1.Controls.Add($lblListe)
$Form1.Controls.Add($lstBxInformations)
$Form1.Controls.Add($btnClose)
$Form1.Name = "Form1"
$Form1.Text = "Form1"
function OnFormClosing_Form1{ 
	# $this est �gal au param�tre sender (object)
	# $_ est �gal au param�tre  e (eventarg)

	# D�terminer la raison de la fermeture :
	#   if (($_).CloseReason -eq [System.Windows.Forms.CloseReason]::UserClosing)

	#Autorise la fermeture
	($_).Cancel= $False
}
$Form1.Add_FormClosing( { OnFormClosing_Form1 } )

#$Form1.Add_Shown({$Form1.Activate()})

$Form1.Add_Shown( {
        $Form1.Activate() ;
        Write-Warning "Add_Shown InvokeRequired =$($Form1.InvokeRequired)"
})


 #On utilise ce script dans un runspace
# $Form1.ShowDialog()
#  #Lib�ration de la Form
# $Form1.Dispose()

