 #La classe suivante peut d�clencher un �v�nement lors de l'insertion,supression d'un �l�ment de la liste.

$listOfParts = new-object System.ComponentModel.BindingList[PSObject]
$listOfParts.AllowNew = $True
$listOfParts.AllowRemove = $True
$listOfParts.AllowEdit = $True;
# Raise ListChanged events when new parts are added.
$listOfParts.RaiseListChangedEvents = $true

 # Add a couple of parts to the list.
$listOfParts.Add((new-Object PSCustomobject -property @{Name="Widget"; Number=1234}))
$listOfParts.Add((new-Object PSCustomobject -property @{Name="Gadget";Number=5647}))  

Register-ObjectEvent $listOfParts ListChanged "ListChanged" -Action {
   Write-WarnIng "ListChanged"
    
   Write-Properties $EventArgs
   Write-Host $EventArgs.ListChangedType.ToString()
   Write-WarnIng "Item :"
   Write-Properties $Sender[$EventArgs.NewIndex]
}

#d�clenche l'�v�nement ListeChanged
$Newpart=$listOfParts.Add((New-Object PSCustomobject -property @{Name="New";Number=7128}))

