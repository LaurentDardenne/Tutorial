#La gestion d'�v�nement de PowerShell ne semble pas savoir g�rer des �v�nements
# renvoyant vers l'objet d�clencheur, des donn�es modifi�es (cf. Eventargs)

#la classe PSMemberSet n'a pas de constructeur par d�faut
#Si l'objet renvoy� par $EventArgs.NewObject est Null, celui-ci appel le constructeur par d�faut
#Le comportement de l'�v�nement AddingNew provoque donc une exception. 
$listOfParts2 = new-object System.ComponentModel.BindingList[System.Management.Automation.PSMemberSet]
$listOfParts2.AllowNew = $true
$listOfParts2.AllowRemove = $True
$listOfParts2.AllowEdit = $True;
# Raise ListChanged events when new parts are added.
$listOfParts2.RaiseListChangedEvents = $true

 # L'�v�nement AddingNew cr�e l'objet � ins�er dans la liste.
 # On peut utiliser la m�thode Add au lieu de AddNew   
Register-ObjectEvent $listOfParts2 AddingNew "AddingNew2" -Action {
 Write-Warning "Event"; 
 Wp $event
 $global:evt=$event.SourceArgs 
 Write-Warning "args 0"; 
 WP $event.SourceArgs[0]
 Write-Warning "args 1"
 Wp $event.SourceArgs[1]
 Write-Warning "args after"
 $obj=New-object System.Management.Automation.PSMemberSet "MonMien"
  Wp $obj
 $Event.SourceArgs[1].NewObject=$Obj
  Write-Warning "new object"
  wp $Event.SourceArgs[1].NewObject
  Write-Warning "Fin"
 #$Sender.EndNew($Sender.Count)
}

Register-ObjectEvent $listOfParts2 ListChanged "ListChanged2" -Action {
   Write-WarnIng "ListChanged"
   wp $EventArgs
   Write-Host $EventArgs.ListChangedType.ToString()
}

$Newpart=$listOfParts2.AddNew()