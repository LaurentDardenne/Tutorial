#La classe ObservableCollection repr�sente une collection de donn�es dynamiques qui fournit des notifications 
#lorsque des �l�ments sont ajout�s, supprim�s ou lorsque la liste enti�re est actualis�e. 

 #N�cessite le framework 3.5, si Out-GridView fonctionne alors c'est OK. 
Add-Type -AssemblyName Windowsbase
 #Repr�sente une collection de donn�es dynamiques qui fournit des notifications 
 # lorsque des �l�ments sont ajout�s, supprim�s, remplac�s, d�plac�s 
 #ou lorsque la liste enti�re est actualis�e. 
$ObservableCol = new-object System.Collections.ObjectModel.ObservableCollection[Int]
 #Classe g�n�rique, acc�s aux membres via psbase
$ObservableCol.psbase|gm -type event

Function Write-Detail($EventArgs,$Comment)
{
   Write-Warning $Comment
    #NewItems            : Obtient la liste des nouveaux �l�ments impliqu�s dans la modification. 
   Write-host "Liste $($EventArgs.NewItems)"
    #NewStartingIndex    : Obtient l'index auquel la modification s'est produite.
   Write-host "Index $($EventArgs.NewStartingIndex)" 
    #OldItems           : Obtient la liste des �l�ments affect�s par une action Replace, Remove ou Move. 
   Write-host "El�ments affect�s $($EventArgs.OldItems)"
    #OldStartingIndex   : Obtient l'index sur lequel une action Move, Remove ou Replace s'est produite.
   Write-host "Index de l'�l�ments affect� $($EventArgs.OldStartingIndex)"
}  

Register-ObjectEvent $ObservableCol CollectionChanged -SourceIdentifier ChangeCollection �Action {
 Write-Detail $EventArgs $EventArgs.Action }
 
#  Switch ($EventArgs.Action) # Obtient l'action qui a d�clench� l'�v�nement. 
#  {
#    # Un ou plusieurs �l�ments ont �t� ajout�s � la collection.
#    "Add"   { 
#              Write-Detail $EventArgs "Add" 
#            } 
#      # Un ou plusieurs �l�ments ont �t� supprim�s de la collection.
#     "Remove" {
#                Write-Detail $EventArgs "Remove"
#              } 
#      # Un ou plusieurs �l�ments ont �t� remplac�s dans la collection.
#     "Replace" {
#                Write-Detail $EventArgs "Replace"
#               }  
#      # Un ou plusieurs �l�ments ont �t� d�plac�s dans la collection.
#     "Move"   {
#                Write-Detail $EventArgs "Move"
#               } 
#      # Le contenu de la collection a chang� de mani�re significative.
#     "Reset"  {
#                Write-Detail $EventArgs "Reset"
#               }  
#  }
# }

$ObservableCol.Add(-99)
$ObservableCol[0]=-59 #Replace
$ObservableCol.Add(10)
"$ObservableCol"
$ObservableCol.Insert(1,6)  
"$ObservableCol"
$ObservableCol.Move(0,($ObservableCol.Count-1))
"$ObservableCol"
$ObservableCol.Remove(6) 
$ObservableCol.Remove(10) 
$ObservableCol.Remove(-59)  
"$ObservableCol"
$ObservableCol.Clear()  
"$ObservableCol"

