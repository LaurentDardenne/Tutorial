#La gestion d'�v�nement de PowerShell ne semble pas savoir g�rer des �v�nements
# renvoyant vers l'objet d�clencheur, des donn�es modifi�es (cf. Eventargs)

#la classe PSCustomObject poss�de un constructeur par d�faut
#Si l'objet renvoy� par $EventArgs.NewObject est Null, celui-ci appel le constructeur par d�faut
#Le comportement de l'�v�nement AddingNew ne provoque pas d'exception, 
# l'objet ins�r� dans la liste n'est pas celui cr�e dans le gestionnaire, mais un objet sans membre. 
$listOfParts = new-object System.ComponentModel.BindingList[PSObject]
$listOfParts.AllowNew = $true
$listOfParts.AllowRemove = $True
$listOfParts.AllowEdit = $True;
# Raise ListChanged events when new parts are added.
$listOfParts.RaiseListChangedEvents = $true

 # Add a couple of parts to the list.
$listOfParts.Add((new-Object PSCustomobject -property @{Name="Widget"; Number=1234}))
$listOfParts.Add((new-Object PSCustomobject -property @{Name="Gadget";Number=5647}))  
Register-ObjectEvent $listOfParts AddingNew "AddingNew" -Action {
 Write-Warning "Event"; 
 Wp $event
 $global:evt=$event.SourceArgs 
 Write-Warning "args 0"; 
 WP $event.SourceArgs[0]
 Write-Warning "args 1"
 Wp $event.SourceArgs[1]
 Write-Warning "args after"
 $obj=New-Object PSCustomobject -property @{Name="New";Number=7128}
  Wp $obj
 $Event.SourceArgs[1].NewObject=$Obj
  Write-Warning "new object"
  wp $Event.SourceArgs[1].NewObject
  Write-Warning "Fin"
 #$Sender.EndNew($Sender.Count)
}

Register-ObjectEvent $listOfParts ListChanged "ListChanged" -Action {
   Write-WarnIng "ListChanged"
   wp $EventArgs
   Write-Host $EventArgs.ListChangedType.ToString()
}

$Newpart=$listOfParts.AddNew()

