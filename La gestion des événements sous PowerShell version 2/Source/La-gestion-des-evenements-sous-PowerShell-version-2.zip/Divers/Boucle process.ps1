#Le but de ce script est de d�marrer un programme s'il n'en existe aucune instance d'active.
#Si ce programme vient � se terminer on le relance automatiquement.

$ProcessInfo=$null
$sbPI={
 
 $Abonne=Get-EventSubscriber "ProcessInfo.Exited" -ea "SilentlyContinue"
 Unregister-Event "ProcessInfo.Exited" -ea "SilentlyContinue"
 if ($Abonne -ne $null) 
  {Remove-Job $Abonne.Action.Id -ea "SilentlyContinue"}
 $ProcessInfo=get-process notepad -ea "SilentlyContinue" 
 if ($ProcessInfo -eq $null) 
  {
    Write-Debug "Start Notepad.exe"
    $ProcessInfo=Start-Process "notepad.exe"
  }
 $null=Register-ObjectEvent $ProcessInfo Exited -SourceIdentifier ProcessInfo.Exited �action ($sbPI -as [Scriptblock])
} 
 #D�marre "l'auto surveillance"
&$sbPI
 #Si on ferme la console PowerShell ce m�canisme est rompu.
#pour arr�ter  
#Unregister-Event "ProcessInfo.Exited" -ea "SilentlyContinue"