$AliasName="wp"

function Write-Properties($From, $PropertyName ="*", [Switch] $Passthru, [Switch] $Silently)
{ #Adaptation d'un script de J.Snoover
  # http://blogs.msdn.com/powershell/archive/2006/12/29/use-copy-property-to-make-it-easier-to-write-read-and-review-scripts.aspx
  #
  #Emet le contenu de toutes les propri�t�s d'un objet sur la console et sur un debugger actif
  #
  # $From         : l'objet � interroger.
  #
  # $PropertyName : le nom de la propri�t�, ce nom peut contenir des jokers.
  #                 C'est un tableau de string, par d�faut on affiche toutes les propri�t�s 
  #
  # $Silently     : N'�met plus les informations sur la console mais seulement vers le debugger actif
  #                 Par d�faut les informations sont �mise sur la console et vers le debugger actif.
  #
  # $Passthru     : Indique l'�mission de l'objet interrog� dans le pipeline.
  #                 Par d�faut il n'est pas �mit.
  #
  #Exemples :
  # $a=dir $env:USERPROFILE
  #  Affiche sur la console
  # Write-Properties $a[-1]
  # 
  #  Affiche sur la console et �met l'objet dans le pipe
  # Write-Properties $a[-1] -pass |%{Write-host $_ -fore DarkGreen}
  # $Fichiers=$A[1..3]|Write-Properties $_ -pass| Where {$_.psiscontainer -eq $false}
  #
  #  �met les datas dans le pipe, aucun affichage sur la console
  # Write-Properties $a[-1] -pass -silently |%{Write-host $_ -fore DarkGreen}
  #
  # Affiche uniquement les propri�t�s list�es
  # wp $A[-1] Name,Extension,L*
  
  
  begin
  {
    $IsDebuggerAttached=[System.Diagnostics.Debugger]::IsAttached
    $CS="Call : {0}" -F $MyInvocation.InvocationName
    Write-Debug $CS;Write-Debug $("-" * 80)

    function WriteProperties($From, $PropertyName,[Switch] $Passthru, [Switch] $Silently){

        if ($IsDebuggerAttached) # faire [System.Diagnostics.Debugger]::Launch()
        {
         $sbDbgWrite={[System.Diagnostics.Debug]::WriteLine($Args[0])} #Pour Visual Studio
         [System.Diagnostics.Debug]::Indent()
        }
        else {$sbDbgWrite={[System.Diagnostics.Debug]::Write($Args[0])}} #Pour DbgView
         #La chaine $CS est envoy� vers le debugger actif
        &$sbDbgWrite $CS
         
        foreach ($P in $From |Get-Member -MemberType *Property -Name $propertyName|Sort name)
        {     
#           #Ps V2  
#           try {   
#             $Result ="$($P.Name) : $($From.$($P.Name))"
#            } catch {
#             $Result ="$($P.Name) : Errror : not applicable"
#            }

           trap {continue}
           $Result ="$($P.Name) : Errror - not applicable."
            #La propri�t� peut contenir un objet
           $Result ="$($P.Name) : $($From.$($P.Name))"        
           #Affiche ou non sur la console.
           #Mais dans tous les cas on affiche au moins sur le d�bugger
          if (!$Silently)
           {Write-Host $Result}
          &$sbDbgWrite $Result
        }
       if ($IsDebuggerAttached)
        {[System.Diagnostics.Debug]::Unindent() }
       &$sbDbgWrite $("-" * 80)             
    }#writeproperties
  }#begin
  
 process
  {
     if ($From -and $_) 
      {throw "Impossible de coupler l'usage du pipeline avec le param�tre `$From"}

     if ($_)
     {   
       Write-Debug ("Process : {0}" -F $_)
         #Affiche les propri�t�s de l'objet
       WriteProperties -From $_ -PropertyName $PropertyName -Silently:$Silently  
         #r��met l'objet
       if ($Passthru) 
        {$_}
     }
  }#process
  
 end
  {
     if ($From)
      { 
        trap {continue}
         #L'op�rateur -F Appel ToString()
         #si un process n'existe plus l'appel �choue.
        Write-Debug ("End : {0}" -F $From)
#           #Ps V2  
#           try {   
#              Write-Debug ("End : {0}" -F $From)        
#            } catch {
#             Write-Debug "End : "Les informations demand�es ne sont pas disponibles"
#            }

        WriteProperties -From $From -PropertyName $PropertyName -Silently:$Silently  
        if ($Passthru)
        {$From}
      }
  }#end
} #Write-Properties
 
 #On informe si on �crase l'existant
 # si l'alias wp est en R/O -> Exception
if (Test-Path alias:$AliasName) 
{ 
 if ((alias $AliasName).Definition -ne "Write-Properties") 
  { Write-Warning "L'alias wp a �t� red�fini." }
}
Set-Alias -name $AliasName -value Write-Properties