$code=@"
using System;
public class TestEventArgs:EventArgs
      {
         public int OldValue;
         public int NewValue;
          
         public TestEventArgs(int aOld, int aNew)
         {
             this.OldValue = aOld;
             this.NewValue = aNew;
         }
     }
"@ 
Add-Type  $code
  
 
[Int32] $I=0
$o=New-object psObject
$o|add-member -membertype NoteProperty I $I
$o|add-member -membertype ScriptProperty `
               -Name Nombre `
               -value { $this.I}`
               -secondvalue {
                  #G�n�re un event propri�taire
                 $event=new-object TestEventArgs($this.I,$Args[0])
                 $this.I=$args[0];
                 New-Event "PowerShell.IncValue" -Sender $this -EventArguments $event -MessageData "Affectation"
               }

Register-EngineEvent "PowerShell.IncValue" -Action {
  write-Warning "$($Event.MessageData). Ancienne valeur $($EventArgs.OldValue)`tnouvelle valeur $($EventArgs.NewValue)"
} 

$o.Nombre=10;
