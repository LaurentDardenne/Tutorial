 #Cr�ation d'un objet personnalis� autour d'un module
 # on renvoi tjr la m�me structure d'objet
function New-CustomObject {
  Param([string]$Texte,[int]$Value) 
         
   #Premi�re passe, on cr�e un objet � partir des membres d'un module dynamique,
   #celui-ci sert � encapsuler des membres priv�s. 
$CustomObject=New-Module -AsCustomObject -ScriptBlock {
  Param([string]$Texte,[int]$Value)
  
    #Cr�e une variable typ�e en lecture seule.
    #Export�e, accessible directement par $Variable.Name 
  New-Variable Name -Option ReadOnly -Value ([String]"$Texte")

   #Cette variable n'est accessible que dans cette port�e interne,
   # les m�thodes internes n'y acc�dent pas. Idem si la port�e est $Local: . 
  [Int] $private:_Private=$Value
  
   #Cette variable n'est pas export�e.
   #Elle reste accessible depuis la fonction GetModuleMember.
  [Int] $Interne=$Value
  
   #Variable export�e en lecture/�criture.
  [Int] $Compteur=0;
  
  $Event=new-object System.Diagnostics.EventLog("Application")
   
   #Hashtable d�finissant les variables du module accessibles de l'ext�rieur.
   #Permet :
   #        - de masquer dans le corps des m�thodes les noms de variables internes,
   #        - de limiter le type d'acc�s depuis l'ext�rieur du module, un membre
   #          de type ScriptProperty peut �tre accessible via la m�thode SetModuleMember.  
  $VariablesProxy=@{
    "Nombre"=@{Name="Interne";Access="RO"}; #Propri�t� en lecture seule.
    "Priv�e"=@{Name="_Private";Access="RW"}; #Ne renvoi pas de r�sultat, aucune erreur de d�clench�e.  
    "Display"=@{Name="(Event.NameLogDisplayName)";Access="RW"}  #La propri�t� cibl�e est en RO.
    "MachineName"=@{Name="Event.Machinename";Access="RW"} #Propri�t� en lecture/�criture, la propri�t� aussi.
  }
   
   #Accesseurs priv�s.
   #Ils acc�dent uniquement aux variables d�clar�es dans la hashtable $VariablesProxy.
  function _GetModuleMember{
   param([String]$Member) 
    Write-Debug "Call _GetModuleMember($member)" 
    if (!$VariablesProxy.ContainsKey($Member)) 
     {Throw "La variable $Member n'existe pas."}
    invoke-expression "Return `$$($VariablesProxy.$Member.Name)"
  }
  
  function _SetModuleMember{
   param([String]$Member,$Value) 
    if (!$VariablesProxy.ContainsKey($Member)) 
     {Throw "La variable $Member n'existe pas."}
    if ($VariablesProxy.$Member.Access -eq "RO")
     {Throw "La variable $MemberName est en lecture seule."}
    if ($Value -eq $Null)
       #La port�e 'Script' doit �tre pr�cis�e pour acc�der en �criture
     { invoke-expression "`$script:$($VariablesProxy.$Member.Name)=`$Null" }
    elseif ($Value -is [string]) 
     { invoke-expression "`$script:$($VariablesProxy.$Member.Name)=`"$Value`"" }
    else { invoke-expression "`$script:$($VariablesProxy.$Member.Name)=$Value" }
  } 

   #Accesseurs publics, ils permettent de se placer dans la port�e du module.
  function GetModuleMember{
   param([String]$MemberName) 
    _GetModuleMember $MemberName 
  }
  function SetModuleMember{
     param([String]$MemberName,$Value) 
    _SetModuleMember $MemberName $Value
  } 

  function AccessTest{
    Write-host "[AccessTest] Priv�e=$private:_Private"
    Write-host "[AccessTest] Interne =$Interne"
  } 
  
  #Ex�cut� une seule fois
 Write-host "[Initialisation] Priv�e=$private:_Private"
 AccessTest
 
  ##Par d�faut toutes les fonctions sont publiques, toutes les variables sont priv�es.
  #Les membres export�e du module deviennent des membres publics 
  #de l'objet cr�� par New-CustomObject. 
 Export-ModuleMember -Variable Name,Compteur`
                     -Function GetModuleMember,SetModuleMember `
 
 #ArgumentList propage les param�tres                     
} -ArgumentList $Texte,$Value

 #Seconde passe, cette fois-ci � l'aide de Add-Member,
 #permet d'acc�der � la variable nomm�ee $Interne (en R/W dans le module) en tant que membre public qui lui est en R/O. 
 #D'o� la d�claration "Nombre"=@{Name="Interne";Access="RO"} qui en m�me temps emp�che l'appel de 
 # SetModuleMember("Nombre",45) 
$CustomObject| add-member -membertype ScriptProperty -Name Nombre -value {$this.GetModuleMember("Nombre")} -Pass |
  add-member -membertype ScriptProperty -Name Display -value {$this.GetModuleMember("Display")} -Pass|
  add-member -membertype ScriptProperty -Name Service -value {$this.GetModuleMember("Service")} -Pass
}

$o=New-CustomObject "Chaine" 99
$o
 #exception:
 # La propri�t� ��Nombre�� est introuvable sur cet objet�; assurez-vous qu'elle existe et qu'elle peut �tre d�finie.
$o.Nombre=5
 #exception:
 # Exception lors de l'appel de ��SetModuleMember�� avec ��2�� argument(s)�: ��La variable nombre est en lecture seule.�� 
$o.SetModuleMember("nombre",5)

