#Gestion d'�v�nement personalis� dans un objet synth�tique 
function New-CustomObject {
  Param( 
         [ValidateNotNullOrEmpty()]
         [string]$VariableName,
         [Scriptblock] $PreModification=$null,
         [Scriptblock] $PostModification=$null)
         
   #On cr�e un objet � partir des membres d'un module.
   #Le module sert � encapsuler des membres priv�s.                                                                               
$CustomObject=New-Module -AsCustomObject -ScriptBlock {
    #Cr�e une variable en lecture seule 
  New-Variable Events -Option ReadOnly -Value ([String[]]@(
     "PSPreModification","PSPostModification"))
  
   #On m�morise le nom de la variable h�bergeant ce module
  New-Variable Name -Option ReadOnly -Value ([String]"$($args[0])")
      
   #Cr�e des variables accessible dans la port�e 
   #de ce module dynamique. 
  [int] $script:_Nombre=0
  
   #Contient un scriptblock li� � 
   #l'�v�nement personnel nomm�e PSPreModification.
  [Scriptblock] $script:PreModification=$null
  [Scriptblock] $script:PostModification=$null
  
  $script:module= $ExecutionContext.SessionState.Module
  
   #Accesseur, permet de se placer dans la port�e du module.
  function GetModuleMember{
     param([String]$MemberName) invoke-expression "Return `$script:$MemberName"}
  function SetModuleMember{
     param([String]$MemberName,$Value) invoke-expression "`$script:$MemberName=`$Value"}

   #Gestion de l'affectation des �v�nements et de leur scriptblock associ�.
   #Cette fonction cr�e l'abonnement � l'�v�nement sp�cifi�e s'il n'existe pas.
   #S'il existe, on l'annule puis on supprime le job associ� avant de recr�er 
   #l'abonnement.
   #
   #ex : La variable PostModification h�berge une copie du scriptblock 
   #     affect� � l'�v�nement PSPostModification.  
  function AssignScriptBlock{
       param([String]$Eventname,[ScriptBlock]$sb)

         if ($Script:Events -notcontains $Eventname)
          {Throw "'$EventName' nom d'�v�nement inconnu. La variable $($Script:Name) ne supporte que les �v�nements suivants : "+
                 "$($oldOfs=$Ofs;$Ofs=', ';"$Script:Events";$ofs=$oldOfs)"}
        
         $JobResult=$null
          #Le pr�fixe "PS" est une convention de nommage 
          #des �v�nements personnel.
          #  1 ev�nement personnel = "PS"+nom_de_la_propri�t�_scriptblock 
         $PropertyName=($Eventname -Split "PS")[1]

          #Syntaxe d'appel interne 
          #On affecte la valeur seulement si c'est n�cessaire.
         if (((GetModuleMember $PropertyName) -eq $null) -and $sb -eq $null) {return}
         
          #R�cup�re l'abonn� $Eventname s'il existe
         $Subcriber=Get-EventSubscriber $Eventname -ea SilentlyContinue
         if ($Subcriber) 
         {
             $Job=$Subcriber.Action.Id
              #on r�cup�re, avant son arr�t, les possibles 
              #donn�es �misent par le job.  
             $JobResult=Receive-Job $Job
               
             #On arr�te le job de l'abonnement, 
             #on se d�sabonne implicitement
            Stop-Job $Job
             #On supprime le job qui �tait associ�
             # l'abonnement de l'�v�nement $Eventname  
            Remove-Job $Job
         }            
          
          #Maj de la propri�t� priv�e
         SetModuleMember $PropertyName $sb
         
         if ($sb -ne $null)
          {
             #On se r�abonne � l'�v�nement avec 
             #le nouveau scriptblock
            $null=Register-EngineEvent $Eventname $sb
          }
         # Si le scriptblock est � $null on a 
         # d�j� annul� l'abonnement 
         
          #on r��met les possibles donn�es pr�c�dement 
          #�misent par le job ($Subcriber.Action)
         $JobResult  
    }

   #Initialise si besoin les abonnements
  if ($args[1] -ne $null)
    { AssignScriptBlock "PSPreModification" $args[1]}
  
  if ($args[2] -ne $null)
    { AssignScriptBlock "PSPostModification" $args[2]}
  
  Export-ModuleMember -Function AssignScriptBlock,GetModuleMember,SetModuleMember `
                      -Variable Name,Events,OnPreModification,OnPostModification 
                        
} -ArgumentList $VariableName,$PreModification,$PostModification
 
 
 #On ajoute des propri�t� synth�tiques pour b�n�ficier des accesseurs getter et setter.
 #Elles acc�dent au propri�t�s priv�es du module � l'aide des fonctions publiques 
 # GetModuleMember et SetModuleMember.
 #Leurs syntaxe d'appel diff�re lors d'un usage � l'ext�rieur du module. 
$CustomObject|add-member -membertype ScriptProperty  -Name Nombre -value {$this.GetModuleMember("_Nombre")} `
    -secondvalue {
        param([int]$Value)
         $Oldvalue=$this.GetModuleMember("_Nombre")
         $this.SetModuleMember("_Nombre",$Value)
         
          #Si un abonnement existe on d�clenche l'�v�nement
         if (Get-EventSubscriber "PSPreModification") 
          {  New-Event "PSPreModification" (gv $this.Name) @{Old=$OldValue} "Valeur de la propri�t� Nombre avant modification " }            

         if (Get-EventSubscriber "PSPostModification") 
          { New-Event "PSPostModification" (gv $this.Name) @{Old=$OldValue;New=$Value} "Valeur de la propri�t� Nombre apr�s modification " }        
            
    } -pass|
     #Propri�t� permettant d'affecter le traitement associ� � un �v�nement.
     #On masque ainsi la gestion des abonnements d'�v�nement tout en la facilitant. 
  add-member -membertype ScriptProperty  -Name OnPreModification -value {$this.GetModuleMember("PreModification")} -secondvalue {
      Param ([Scriptblock] $Value)
      $this.AssignScriptBlock("PSPreModification",$Value) } -pass|
  add-member -membertype ScriptProperty  -Name OnPostModification -value {$this.GetModuleMember("PostModification")} -secondvalue {
       Param ([Scriptblock] $Value)
       $this.AssignScriptBlock("PSPostModification",$Value) } -pass|
    add-member -membertype ScriptMethod -Name DisposeAndRemove -value {
       #S'ils sont d�clar�s, on supprime 
       #les abonnements en cours
      if ($this.OnPreModification -ne $null) 
       {$this.OnPreModification=$null}
      if ($this.OnPostModification -ne $null) 
       {$this.OnPostModification=$null}
       #Last but not least
       #Supprime la variable dans la port�e parente
      Remove-Variable $this.Name -Scope 1
  }
$CustomObject
}

 #------- Usage ------------

#Initialisation
$sbPre={
   Write-Host ("[PreProcess] Old={0}" �F $Event.SourceArgs[0].Old) -Fore green
 }
$sbPost={
   Write-Host ("[PostProcess] Old={0}`tNew={1}" �F $Event.SourceArgs[0].Old, $Event.SourceArgs[0].New) -Fore green
 }
$ObjEvt=New-CustomObject "ObjEvt" $sbPre $sbPost
$ObjEvt
$ObjEvt.Nombre
$ObjEvt.Nombre=2

get-eventSubscriber
get-job
 $MonObjet.OnPreModification
 $MonObjet.OnPreModification=$null
 $MonObjet.Nombre=12
get-eventSubscriber
get-job
 gv $MonObjet.Name 
 $MonObjet.DisposeAndRemove()
get-eventSubscriber
get-job
 gv $MonObjet.Name

 #------- Tests et limite de la solution ------------

 #Aucun probl�me. 
 #Seul les jobs Stopped sont concern�s
$MonObjet.Nombre=-1
$ObjEvt=New-CustomObject "ObjEvt" $sbPre $sbPost
$ObjEvt
Remove-job *

 #Probl�me : pas de suppression des abonnements
$ObjEvt=New-CustomObject "ObjEvt" $sbPre $sbPost
$ObjEvt=$null
get-eventSubscriber
 
 #Probl�me : pas de maj des propri�t�s des abonnements
$ObjEvt=New-CustomObject "ObjEvt" $sbPre $sbPost
$ObjEvt
Unregister-Event *

 #Probl�me : on �crase les abonnements des objets pr�c�dents
 # tous les objets partage les m�mes nom d'identifiant d'�v�nement 
$Obj=New-CustomObject "Obj" $sbPre $sbPost
$Obj
