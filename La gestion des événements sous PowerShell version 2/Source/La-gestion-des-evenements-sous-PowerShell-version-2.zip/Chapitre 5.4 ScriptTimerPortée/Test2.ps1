$timer2 = New-Object Timers.Timer ; $timer2.Interval = 500
$Evt2=Register-ObjectEvent -inputObject $timer2 -eventName Elapsed  -sourceIdentifier Timer2 -Action { 
 $varSession +=2
 $local:varLocal +=5
 $Global:MyVar +=5
 $Script:Persiste +=10
 
 Write-Warning "Modification Timer2 :"
  Write-host "`t`$VarSession=$varSession"  ;  Write-host "`t`$local:varLocal=$local:varLocal"
  Write-host "`t`$Global:MyVar=$Global:MyVar" ;  Write-host "`t`$Script:Persiste=$Script:Persiste"
}
$timer2.Enabled = $true
  

