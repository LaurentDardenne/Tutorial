$varSession=1
$varLocal=0
$Global:MyVar=5
$Script:Persiste=10

 #d�clenche la modification des variables dans 2 jobs d'�v�nement distincts 
. .\Test1.ps1  #Timer1
. .\Test2.ps1  #Timer2
# Dans Test 1
#  $varSession +=1
#  $local:varLocal +=3
#  $Global:MyVar +=4
#  $Script:Persiste +=5
#
# Dans Test2
#  $varSession +=2
#  $local:varLocal +=5
#  $Global:MyVar +=5
#  $Script:Persiste +=10

Write-Host "Attente de deux secondes..." -fore Green
Sleep 2
 #Arr�te la modification des variables
$timer1.Enabled = $False
$timer2.Enabled = $False
 
 #Affiche le r�sultat apr�s l'ex�cution des 2 jobs d'�v�nement
Sleep -m 250
Write-Host "R�sultat de l'ex�cution de Test1 et Test2  : Persiste" -fore Green
  Write-host "`$VarSession=$varSession"  ;  Write-host "`$local:varLocal=$local:varLocal"
  Write-host "`$Global:MyVar=$Global:MyVar" ;  Write-host "`$Script:Persiste=$Script:Persiste"
Write-Host "`tSeule la variable globale est modifi�e par tous les jobs." -fore white
Write-Host "`tLes autres variables sont persistentes apr�s chaque appel, mais sont propre � chaque job." -fore Green
Write-Host "`tLes variables `$varSession, `$local:varLocal et `$Script:Persiste sont propre au script Main." -fore Green

unregister-event $Evt1.Name ;Remove-Job $Evt1.ID
unregister-event $Evt2.Name ;Remove-Job $Evt2.ID

