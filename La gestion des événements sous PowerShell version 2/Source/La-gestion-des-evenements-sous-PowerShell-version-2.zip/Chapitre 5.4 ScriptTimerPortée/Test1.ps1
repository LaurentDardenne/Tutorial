$timer1 = New-Object Timers.Timer ; $timer1.Interval = 500
$Evt1=Register-ObjectEvent -inputObject $timer1 -eventName Elapsed -sourceIdentifier Timer1 -Action { 
 $varSession +=1
 $local:varLocal +=3
 $Global:MyVar +=5
 $Script:Persiste +=7
 
 Write-Warning "Modification Timer1 :"
  Write-host "`$VarSession=$varSession"  ;  Write-host "`$local:varLocal=$local:varLocal"
  Write-host "`$Global:MyVar=$Global:MyVar" ;  Write-host "`$Script:Persiste=$Script:Persiste"
}
$timer1.Enabled = $true

