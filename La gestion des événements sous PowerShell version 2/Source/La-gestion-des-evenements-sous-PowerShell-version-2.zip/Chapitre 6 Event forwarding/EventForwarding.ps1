#Ex�cutez une nouvelle session de PowerShell.exe
Register-EngineEvent �SourceIdentifier Exited �Action  {
 Write-host "Fin de process issu de la session secondaire." -fore green 
 Write-host "Event EntryWritten" 
 Write-Warning "EventSubscriber"; Write-Properties $EventSubscriber
 Write-Warning "Event"; wp $Event
 Write-Warning "Eventargs"; wp $EventArgs; 
 Write-Warning "Sender"; wp $Sender; 
}

$session1 = New-PSSession -ComputerName localhost
Enter-PsSession $session1
$P=Microsoft.PowerShell.Management\start-process Notepad.exe �pass
Register-ObjectEvent $P Exited -SourceIdentifier Exited -forward
Exit

$session2 = New-PSSession -ComputerName localhost
Invoke-Command $session2 {
 $P=Microsoft.PowerShell.Management\start-process Notepad.exe �pass
 Register-ObjectEvent $P Exited -SourceIdentifier Exited -forward
}

Invoke-Command $session1,$session2 {Stop-Process -id $P.Id}



