#Test-LeapYear.ps1 
#http://blogs.msdn.com/powershell/archive/2008/12/23/advanced-functions-and-test-leapyear-ps1.aspx
<# 
.Synopsis 
    Determines whether a year is a leapyear or not. 
.Description 
    This is a simple function to demonstrate the capabilities of PowerShell 
    V2 Advanced Functions by telling whether a year is a leap year or not. 
.Parameter Year 
    Which year would you like tested? 
.Example 
    PS> Test-LeapYear 2008 

.ReturnValue 
    [Boolean] 

.Link 
    about_functions 
    about_functions_advanced 
    about_functions_advanced_methods 
    about_functions_advanced_parameters 

.Notes 
NAME:      Verb-Noun 
AUTHOR:    NTDEV\jsnover 
LASTEDIT:  12/22/2008 20:39:07 
#Requires -Version 2.0 
#> 

param( 
[Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true)] 
[Int]$Year 
) 

Process 
{ 
    [DateTime]::IsLeapYear($Year) 
}#Process 

