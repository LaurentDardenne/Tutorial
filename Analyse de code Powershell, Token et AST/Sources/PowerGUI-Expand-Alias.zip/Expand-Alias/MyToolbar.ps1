﻿#from http://blogs.microsoft.co.il/scriptfanatic/2010/07/01/powergui-take-control-of-the-script-editor/
$se = [Quest.PowerGUI.SDK.ScriptEditorFactory]::CurrentInstance
$ic = New-Object Quest.PowerGUI.SDK.ItemCommand 'ToolsCommand','ExpandAlias'
$ic.ScriptBlock = {

    $Aliases = Get-Alias 
    $doc = $se.CurrentDocumentWindow.Document   

    $Tokens = [System.Management.Automation.PsParser]::Tokenize($doc.Text,[ref]$null) | Where-Object {$_.Type -eq 'Command'}
    $Tokens | Sort-Object StartLine, StartColumn -Descending | ForEach-Object {

        $Alias = $_.Content
        $ResolvedCommandName = ( $Aliases | Where-Object  {$_.Name -eq $Alias} ).ResolvedCommandName

        if($ResolvedCommandName)
        {
            $doc.Select($_.StartLine,$_.StartColumn,$_.EndLine,$_.EndColumn)
            $doc.SelectedText = $ResolvedCommandName
        }
    }
}

$ic.Text = '&Expand Alias'
$ic.Image= New-Object System.Drawing.Icon -ArgumentList "C:\UpDown.ico",16,16
$ic.AddShortcut('Control+E')
$se.Commands.Add($ic)
$expand = $se.Commands['ToolsCommand.ExpandAlias']

$toolbar = New-Object Quest.PowerGUI.SDK.Toolbar MyToolBar
$toolbar.Visible=$true
$toolbar.Items.Add($expand)
$se.Toolbars.Add($toolbar)