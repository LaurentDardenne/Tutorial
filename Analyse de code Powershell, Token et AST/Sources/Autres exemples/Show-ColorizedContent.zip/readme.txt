Usage:
Show-ColorizedContent.ps1 filename [highlight range]

If provided, "highlight range" is a list of any line numbers for the script highlight. This uses PowerShell's standard array range syntax.

Show-ColorizedContent Show-ColorizedContent.ps1 -Highlight (48..49+83..94)




By default, the console colors are extremely gaudy and make for ugly syntax highlighting. Use the commands below to update the color table for PowerShell.exe:




Push-Location

Set-Location HKCU:\Console\
New-Item %SystemRoot%_system32_WindowsPowerShell_v1.0_powershell.exe -ea SilentlyContinue
Set-Location %SystemRoot%_system32_WindowsPowerShell_v1.0_powershell.exe

Set-ItemProperty . ColorTable00 5645313 -Type DWORD
Set-ItemProperty . ColorTable01 11158596 -Type DWORD
Set-ItemProperty . ColorTable02 4500036 -Type DWORD
Set-ItemProperty . ColorTable03 11184708 -Type DWORD
Set-ItemProperty . ColorTable04 4474026 -Type DWORD
Set-ItemProperty . ColorTable05 11158698 -Type DWORD
Set-ItemProperty . ColorTable06 4500138 -Type DWORD
Set-ItemProperty . ColorTable07 15789550 -Type DWORD
Set-ItemProperty . ColorTable09 13395660 -Type DWORD
Set-ItemProperty . ColorTable10 6736998 -Type DWORD
Set-ItemProperty . ColorTable11 13421670 -Type DWORD
Set-ItemProperty . ColorTable12 6710988 -Type DWORD
Set-ItemProperty . ColorTable13 13395660 -Type DWORD
Set-ItemProperty . ColorTable14 6737100 -Type DWORD

Pop-Location
