﻿
#..\Modules         : GUID = 'a5d7c151-56cf-40a4-839f-0019898eb324'
#..\FabrikamModules :  GUID = '9df5e76c-91a5-46f2-8e3f-1683d42ea1c8'

$oldPSModulePath=$env:PSModulePath

$Path=$PSScriptRoot #c:\temp\Tests
$env:PSModulePath +=";$Path\FabrikamModules\Computer1.0;$Path\Modules\Computer1.0"
#OR $env:PSModulePath +=";$Path\FabrikamModulesV5;$Path\ModulesV5"

ipmo -FullyQualifiedName @{ModuleName="Computer";ModuleVersion='1.0';GUID = '9df5e76c-91a5-46f2-8e3f-1683d42ea1c8' }
Get-module Computer|Select Name,Version,GUID
# Name     Version Guid
# ----     ------- ----
# Computer 1.0     9df5e76c-91a5-46f2-8e3f-1683d42ea1c8
Remove-Module Computer

# - Requires.ps1 :
## Requires -Modules @{ModuleName="Computer";ModuleVersion='1.0';GUID = '9df5e76c-91a5-46f2-8e3f-1683d42ea1c8' }
.\Requires.ps1
Get-module Computer|Select Name,Version,GUID #ok
Remove-Module Computer

$env:PSModulePath =$oldPSModulePath+";$Path\Modules\Computer1.0;$Path\FabrikamModules\Computer1.0"
# OR $env:PSModulePath =$oldPSModulePath+";$Path\ModulesV5;$Path\FabrikamModulesV5"

ipmo -FullyQualifiedName @{ModuleName="Computer";ModuleVersion='1.0';GUID = '9df5e76c-91a5-46f2-8e3f-1683d42ea1c8' }
Get-module Computer|Select Name,Version,GUID #ok
Remove-Module Computer
.\Requires.ps1

# Exception
# \Requires.ps1 : The script 'Requires.ps1' cannot be run because the following modules that are specified by the
# "#requires" statements of the script are missing: Computer.
Get-module Computer|Select Name,Version,GUID 
# Name     Version Guid
# ----     ------- ----
# Computer 1.0     9df5e76c-91a5-46f2-8e3f-1683d42ea1c8
