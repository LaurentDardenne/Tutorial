﻿#Requires -Modules @{ModuleName="Computer";ModuleVersion='1.0';GUID = '9df5e76c-91a5-46f2-8e3f-1683d42ea1c8' }

#-Requires -Modules @{ModuleName="Computer";ModuleVersion='1.0';GUID = 'a5d7c151-56cf-40a4-839f-0019898eb324'}
#-Requires -Modules @{ModuleName="Computer";RequiredVersion='1.0';GUID = '9df5e76c-91a5-46f2-8e3f-1683d42ea1c8' }

#..\Module         : GUID = 'a5d7c151-56cf-40a4-839f-0019898eb324'
#..\FabrikamModule :  GUID = '9df5e76c-91a5-46f2-8e3f-1683d42ea1c8' 
Get-ComputerVersion
$m=Get-Module Computer
Write-host ("{0}  {1}  {2}" -f $m.Name,$m.version,$m.guid)